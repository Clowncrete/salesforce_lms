import { LightningElement, api, track } from 'lwc';

export default class ItemsList extends LightningElement {
   @api itemList;
   @track itemList;
}