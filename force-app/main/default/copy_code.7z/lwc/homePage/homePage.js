import { LightningElement, wire, track } from 'lwc';
import apexMethodName from '@salesforce/apex/ItemTestClass.getItemTypes';
import getItemList from '@salesforce/apex/ItemController.getItemList';
import searchItems from '@salesforce/apex/ItemController.searchItems';
import addCheckoutItems from '@salesforce/apex/CheckoutController.addCheckoutItems';

export default class HomePage extends LightningElement {
   @track types;
   @track itemList;
   searchString = '';
   typeString = '';
   //barcodesList = ['121212121212'];
   
   barcodesList = [];

   queryTerm = "";
   noRecordsFound = false;

    handleKeyUp(evt) {
        const isEnterKey = evt.keyCode === 13;
        if (isEnterKey) {
            this.queryTerm = evt.target.value;
        }
        this.searchItems(this.queryTerm);
    }

   @wire(apexMethodName, {})
   getTypes({ error, data }){
      if(data){
         this.types = data;
      } 
      else {
      }
   }

  /* @wire(getItemList, {})
   getItemList({error, data}) {
      if(data){
         this.itemList = data;
      } 
      else {
      }
   }
*/
   @wire(searchItems, {
      searchString: '$searchString',
      type: '$typeString'
   })
   search({error, data}) {
      if(data){
         this.itemList = data;
         if(this.itemList.length < 1) {
            this.noRecordsFound = true;
         }
         else {
            this.noRecordsFound = false;
         }
      } 
      else {
      }
   }

   /*@wire(addCheckoutItems, {
      barcodes: '$barcodesList'
   }) 
   addCheckoutItems(){
      //debugger;
      //this.barcodesList = [];
      /*for(let i = 0; i < this.data.length; i++) {
         this.barcodesList.push(this.data[i].barcode);
      }
   }
*/
   addCheckoutItems1(){
      //this.barcodesList = [];
      for(let i = 0; i < this.data.length; i++) {
         this.barcodesList.push(this.data[i].barcode);
      }
      addCheckoutItems({barcodes: this.barcodesList}).then(result => {debugger;});
   }
   isBookOrMagazine(type) {
      if(type === 'Book' || type === 'Magazine') {
         return true;
      } else {
         return false;
      }
   }

   searchItems(searchText) {
      this.searchString = searchText;
   }

   onCheckout() {
      this.openModal();
   }

   @track isModalOpen = false;
    openModal() {
        // to open modal set isModalOpen tarck value as true
        this.isModalOpen = true;
    }
    closeModal() {
        // to close modal set isModalOpen tarck value as false
        this.isModalOpen = false;
    }
    submitDetails() {
        // to close modal set isModalOpen tarck value as false
        //Add your code to call apex method or do some processing
        this.addCheckoutItems1();
        this.isModalOpen = false;
   }

   addItem(e) {
      if(e && e.detail) {
         this.data.push({name: e.detail.Name, barcode: e.detail.ItemBarCode__c
         });
      }
   }

   removeItem(e) {
   }

   actions = [
      { label: 'Delete', name: 'delete' },
  ];
  
  columns = [
      { label: 'Name', fieldName: 'name' },
      { label: 'Barcode', fieldName: 'barcode' },
      {
          type: 'action',
          typeAttributes: { rowActions: this.actions },
      },
  ];

   data = [];
   record = {};

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'delete':
                this.deleteRow(row);
                break;
            default:
        }
    }

    deleteRow(row) {
       debugger;
        /*const { id } = row;
        const index = this.findRowIndexById(id);
        if (index !== -1) {
            this.data = this.data
                .slice(0, index)
                .concat(this.data.slice(index + 1));
        }*/
    }

    findRowIndexById(id) {
       debugger;
        /*let ret = -1;
        this.data.some((row, index) => {
            if (row.id === id) {
                ret = index;
                return true;
            }
            return false;
        });
        return ret;*/
    }

}